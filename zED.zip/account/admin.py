from django.contrib import admin
from account.models import Account

admin.site.register(Account)
