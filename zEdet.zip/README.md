# EarthMonitor
satellite image process by collective wisdom
